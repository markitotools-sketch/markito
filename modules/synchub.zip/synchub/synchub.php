<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: SyncHub
Description: Multi-company and multi-branch synchronization system for Perfex CRM.
Version: 1.0.0
Requires at least: 2.3.*
*/

define('SYNCHUB_MODULE_NAME', 'synchub');

register_activation_hook(SYNCHUB_MODULE_NAME, 'synchub_activation_hook');

function synchub_activation_hook()
{
    require_once __DIR__ . '/install.php';
}